//----------------------------------------------------------------
//daqui para baixo começa o js do site

//buca no site pelo titulo e armazena ele dentro da variavel
let titulo = document.querySelector(".titulo");
//mostra no devtools o conteudo de texto da variavel titulo para fins de teste
console.log(titulo.textContent);
//altera o conteudo da variavel titulo para o texto desejado
titulo.textContent = "Fica Grande Nutrição";
